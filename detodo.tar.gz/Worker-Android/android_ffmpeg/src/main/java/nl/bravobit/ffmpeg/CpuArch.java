package nl.bravobit.ffmpeg;

public enum CpuArch {
    ARMv7, x86, NONE
}
