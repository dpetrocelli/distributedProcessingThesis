package ImageCreationAndProcessing;

import java.io.File;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;


public class DataObtainer 
{
    public static void main( String[] args )
    {
    	File folder = new File("C:/Users/l12082/Desktop/captures/");
    	
    	File[] listOfFiles = folder.listFiles();
    	Tesseract tesseract = new Tesseract();
    	tesseract.setDatapath("C:\\tesseract"); 
    	tesseract.setLanguage("eng");
    	
    	for (int i = 0; i < listOfFiles.length; i++) {
    	  if (listOfFiles[i].isFile()) {
    		String time = listOfFiles[i].getName();
    	    String path = listOfFiles[i].getAbsolutePath();
    	    try {
    			String fullText = tesseract.doOCR(new File (path));
    			if (fullText.length()>5) System.out.println("Inst. Watt Consum. "+fullText.trim()+ " ON TIME: "+time.substring(0, (time.length()-4)));
    		} catch (TesseractException e) {
    			// TODO Auto-generated catch block
    			System.out.println(" NO TEXT IMAGE ");
    		}
    	  }
    	
    	}
    }
}
